# SubAudit AI — Prototype

An AI agent that audits SaaS subscriptions: it reads inbox/billing text and usage data,
flags subscriptions that are unused, duplicated, or facing a price hike, and drafts
cancellation/negotiation emails.

## What's actually in this package

- **`index.html`** — the working prototype. Open it directly in a browser.
  Paste in sample or real inbox/billing text, click "Run audit," and it makes a
  **live LLM call** to extract and flag subscriptions, then drafts emails on demand.
- **`gemini_backend_example.py`** — a standalone Python script showing the same
  extraction + drafting logic, but calling the **Gemini API** instead. Use this if your
  project requires Gemini/Vertex AI specifically (e.g. hackathon rules).

## Important limitations — read before you demo this

1. **`index.html` calls Claude, not Gemini.** It only works when opened inside a
   Claude.ai artifact environment, because that's what routes the API call and handles
   auth automatically. It will **not** work as a standalone file opened in a normal
   browser outside that environment — there's no API key wired in.
2. **No live Gmail or bank integration.** You paste text in manually. Wiring a real
   Gmail API / Plaid connection is a separate OAuth + backend build, not included here.
3. **No persistence.** Nothing is saved between sessions.
4. **`gemini_backend_example.py` needs your own Gemini API key** and needs to be run
   locally (`pip install google-generativeai`, set `GEMINI_API_KEY`, then run it with
   sample text). It's a starting point, not a deployed service.

## If you want this to be a real, deployable product

You'd need, roughly in order of priority:
1. A real backend (Flask/FastAPI) hosting the extraction/drafting logic
2. Gmail API OAuth to actually pull invoice/renewal emails
3. A transaction data source (Plaid, or manual CSV upload as a first step)
4. Deployment (Cloud Run fits well — scales to zero, cheap for low-traffic use)
5. A review/approval step before any email actually sends — don't auto-send drafted
   cancellation emails without a human in the loop, the flagging logic will be wrong
   sometimes and you don't want it cancelling something you still need.
