"""
SubAudit AI — Gemini backend example

A standalone script showing the extraction + drafting logic running against
the real Gemini API. This is the version to use if your project needs to be
"built on Gemini / Google Cloud" specifically.

Setup:
    pip install google-generativeai
    export GEMINI_API_KEY="your-key-here"
    python gemini_backend_example.py

This is a prototype: it runs once on the SAMPLE_TEXT below and prints results.
It does not connect to Gmail or a bank feed — wire that in separately.
"""

import os
import json
import re

import google.generativeai as genai

API_KEY = os.environ.get("GEMINI_API_KEY")
if not API_KEY:
    raise SystemExit("Set the GEMINI_API_KEY environment variable before running this.")

genai.configure(api_key=API_KEY)
MODEL_NAME = "gemini-2.5-pro"  # swap for whichever Gemini model you have access to

model = genai.GenerativeModel(MODEL_NAME)

SAMPLE_TEXT = """
--- INBOX EMAILS ---

From: billing@asana.com
Subject: Your Asana Business plan renews soon
Body: Your Business plan (Account MC-4471, 8 seats) will renew on Sep 14 for $249.00/month.

From: noreply@monday.com
Subject: Payment receipt — Monday.com
Body: Thanks for your payment of $96.00 for your Standard plan, 2 seats active.

From: adobe@adobe.com
Subject: Price update for your Creative Cloud plan
Body: Starting Sep 14, your Creative Cloud All Apps plan will increase from $73.00/month to $89.00/month.

From: team@loom.com
Subject: Your Loom invoice
Body: Charged $96.00/month for your Business plan, 4 seats.

--- USAGE / LOGIN DATA ---
Asana: last login 94 days ago, 1 of 8 seats logged in this quarter
Monday.com: last login 12 days ago, same task-tracking function as Asana
Loom: last login 61 days ago, 0 of 4 seats active in 60 days
Adobe Creative Cloud: 2 of 2 seats actively used weekly
"""


def extract_json_array(text: str):
    """Pull a JSON array out of a model response, tolerating stray text/fences."""
    cleaned = re.sub(r"```json|```", "", text).strip()
    start = cleaned.find("[")
    end = cleaned.rfind("]")
    if start == -1 or end == -1:
        raise ValueError(f"Could not find a JSON array in model output:\n{text}")
    return json.loads(cleaned[start : end + 1])


def run_extraction(raw_text: str):
    prompt = f"""You are the extraction and verification agent for a SaaS subscription audit tool.

Read the text below (billing/renewal emails plus usage/login data) and identify every
subscription mentioned. Cross-reference billing info against usage data to decide if it
should be flagged.

Flag categories (use only these): "unused", "duplicate", "hike", "ok".

Respond with ONLY a JSON array, no preamble, no markdown fences. Each object needs:
- "name": string
- "detail": string, under 12 words, factual reason
- "amount": number, monthly cost in dollars
- "flag": one of "unused" | "duplicate" | "hike" | "ok"

Text to analyze:
\"\"\"
{raw_text}
\"\"\"
"""
    response = model.generate_content(prompt)
    return extract_json_array(response.text)


def draft_email(item: dict) -> str:
    action = (
        "negotiate the price back down or ask for the previous rate"
        if item["flag"] == "hike"
        else "cancel the subscription"
    )
    prompt = f"""Write a short, professional email to a SaaS vendor's billing team.

Vendor/tool: {item['name']}
Situation: {item['detail']}
Monthly cost: ${item['amount']}
Goal: {action}

Respond with plain text:
SUBJECT: <subject line>
BODY:
<email body, 3-5 sentences, professional, direct, signed "— Ops Team">
"""
    response = model.generate_content(prompt)
    return response.text


def main():
    print("Running extraction against sample data...\n")
    items = run_extraction(SAMPLE_TEXT)

    flagged = [i for i in items if i["flag"] != "ok"]
    monthly_total = sum(i["amount"] for i in flagged)

    print(f"Flagged {len(flagged)} of {len(items)} subscriptions")
    print(f"Flagged monthly spend: ${monthly_total:.2f}")
    print(f"Estimated annual savings: ${monthly_total * 12:.2f}\n")

    for item in items:
        print(f"- {item['name']:20s} [{item['flag']:9s}] ${item['amount']:.2f}/mo  {item['detail']}")

    if flagged:
        print("\n--- Example draft for first flagged item ---\n")
        print(draft_email(flagged[0]))


if __name__ == "__main__":
    main()
